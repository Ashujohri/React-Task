var mysql = require('mysql2');

var pool = mysql.createPool({
    host: "localhost",
    port: 3306,
    user: "root",
    password: "1234",
    database: "reacttask",
    connectionLimit: 100,
    multipleStatements: true,
});

module.exports = pool;